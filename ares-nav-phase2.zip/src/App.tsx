import { useState } from "react";
import {
  GALE_SITE,
  MARS_GRAVITY_MS2,
  PNR_CRITICAL_FRACTION,
  SLOPE_ABORT_DEG,
  WAL_CAPACITY_PACKETS
} from "./core/constants";

type OperationalMode = "HABITAT" | "VISOR";

type SubsystemState = "NOT LOADED" | "NOT INITIALISED";

interface Subsystem {
  readonly name: string;
  readonly state: SubsystemState;
}

const operationalModes: ReadonlyArray<OperationalMode> = ["HABITAT", "VISOR"];

const formatAxis = (value: number, positiveHemisphere: string, negativeHemisphere: string): string =>
  `${Math.abs(value).toFixed(3)}°${value >= 0 ? positiveHemisphere : negativeHemisphere}`;

const missionParameters: ReadonlyArray<readonly [string, string]> = [
  ["SITE LATITUDE", formatAxis(GALE_SITE.latitudeDeg, "N", "S")],
  ["SITE LONGITUDE", formatAxis(GALE_SITE.longitudeDeg, "E", "W")],
  ["DATUM ELEVATION", `${GALE_SITE.datumElevationM} m`],
  ["SURFACE GRAVITY", `${MARS_GRAVITY_MS2.toFixed(3)} m/s²`],
  ["PNR CRITICAL FRACTION", `${(PNR_CRITICAL_FRACTION * 100).toFixed(0)} %`],
  ["SLOPE ABORT LIMIT", `${SLOPE_ABORT_DEG} deg`],
  ["WAL CAPACITY", `${WAL_CAPACITY_PACKETS} packets`]
];

const subsystems: ReadonlyArray<Subsystem> = [
  { name: "TERRAIN GRID", state: "NOT LOADED" },
  { name: "SPATIAL STORE", state: "NOT INITIALISED" },
  { name: "TELEMETRY WAL", state: "NOT INITIALISED" },
  { name: "PATHFINDER WORKER", state: "NOT INITIALISED" },
  { name: "VIEWSHED WORKER", state: "NOT INITIALISED" }
];

const ModeSwitch = ({
  mode,
  onSelect
}: {
  readonly mode: OperationalMode;
  readonly onSelect: (next: OperationalMode) => void;
}) => (
  <div className="mode-switch" role="group" aria-label="Operational mode">
    {operationalModes.map((candidate) => (
      <button
        key={candidate}
        type="button"
        className={candidate === mode ? "mode-button active" : "mode-button"}
        aria-pressed={candidate === mode}
        onClick={() => onSelect(candidate)}
      >
        {candidate}
      </button>
    ))}
  </div>
);

const ParameterTable = () => (
  <table className="readout">
    <tbody>
      {missionParameters.map(([label, value]) => (
        <tr key={label}>
          <th scope="row">{label}</th>
          <td>{value}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

const SubsystemTable = () => (
  <table className="readout">
    <tbody>
      {subsystems.map(({ name, state }) => (
        <tr key={name}>
          <th scope="row">{name}</th>
          <td className="dim">{state}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

export const App = () => {
  const [mode, setMode] = useState<OperationalMode>("HABITAT");

  return (
    <div className={mode === "VISOR" ? "console visor" : "console habitat"}>
      <header className="bar">
        <span className="title">ARES-NAV</span>
        <ModeSwitch mode={mode} onSelect={setMode} />
      </header>
      <main className="panels">
        <section className="panel">
          <h2>MISSION PARAMETERS</h2>
          <ParameterTable />
        </section>
        <section className="panel">
          <h2>SUBSYSTEMS</h2>
          <SubsystemTable />
        </section>
      </main>
    </div>
  );
};
