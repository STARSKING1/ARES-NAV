# ARES-NAV

Offline-first Martian EVA navigation and suit-avionics platform for the 2026 NASA Space Apps Challenge, "Interplanetary Survival Guide: Martian Map". Target area: Gale Crater, Mount Sharp boxwork ridges.

## Verify

```
npm install
npm run verify
```

`verify` runs the zero-comment check, the Vitest suite and the production build. GitHub Actions runs the same steps on every pull request.

## Data

Place the HiRISE/MOLA terrain crop under `data/raw/`. Preprocessing and checksum generation arrive in the data-layer phase.

## NASA data attribution

MRO HiRISE, MGS MOLA, MRO CRISM, Mars Odyssey THEMIS, Curiosity RAD, REMS and Mastcam, and NASA Mars Trek WMTS. Each source is listed with its role as it is integrated.
