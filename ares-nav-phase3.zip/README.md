# ARES-NAV

Offline-first Martian EVA navigation and suit-avionics platform for the 2026 NASA Space Apps Challenge, "Interplanetary Survival Guide: Martian Map". Target area: Gale Crater, Mount Sharp boxwork ridges.

## Verify

```
npm install
npm run verify
```

`verify` runs the zero-comment check, the Vitest suite and the production build. GitHub Actions runs the same steps on every pull request.

## Data

The Gale sector is currently a deterministic synthetic terrain (`SYNTHETIC_GALE_CALIBRATED`), generated in `src/terrain/galeSectorGenerator.ts` with a pinned SHA-256 in the tests. It is labelled as synthetic in the data model and must not be presented as measured HiRISE data. A real HiRISE/MOLA crop placed under `data/raw/` will load with the `HIRISE_DTM` provenance.

## NASA data attribution

MRO HiRISE, MGS MOLA, MRO CRISM, Mars Odyssey THEMIS, Curiosity RAD, REMS and Mastcam, and NASA Mars Trek WMTS. Each source is listed with its role as it is integrated.
